package org.jdesktop.xswingx;

import org.jdesktop.xswingx.JXPromptField;

public class JXPromptFieldBeanInfo extends JXPromptBeanInfo {
	public JXPromptFieldBeanInfo() {
		super(JXPromptField.class);
	}
}
