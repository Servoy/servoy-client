package org.jdesktop.xswingx;

import org.jdesktop.xswingx.JXFormattedTextField;

public class JXFormattedTextFieldBeanInfo extends JXPromptBeanInfo {
	public JXFormattedTextFieldBeanInfo() {
		super(JXFormattedTextField.class);
	}
}
