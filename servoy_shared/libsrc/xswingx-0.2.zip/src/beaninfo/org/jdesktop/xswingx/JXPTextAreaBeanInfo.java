package org.jdesktop.xswingx;

import org.jdesktop.xswingx.JXTextArea;

public class JXPTextAreaBeanInfo extends JXPromptBeanInfo {
	public JXPTextAreaBeanInfo() {
		super(JXTextArea.class);
	}
}
