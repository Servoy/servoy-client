package org.jdesktop.xswingx;

import org.jdesktop.xswingx.JXFormattedPromptField;

public class JXFormattedPromptFieldBeanInfo extends JXPromptBeanInfo {
	public JXFormattedPromptFieldBeanInfo() {
		super(JXFormattedPromptField.class);
	}
}
