package org.jdesktop.xswingx.plaf;

import org.junit.Test;


public class BuddyTextFieldUITest {
	
}
