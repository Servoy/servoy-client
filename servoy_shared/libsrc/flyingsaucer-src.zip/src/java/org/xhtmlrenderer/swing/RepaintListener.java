package org.xhtmlrenderer.swing;

/**
 * Created by IntelliJ IDEA.
 * User: pdoubleya
 * Date: Apr 20, 2009
 * Time: 10:54:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RepaintListener {
    void repaintRequested(boolean doLayout);
}
