package org.jdesktop.xswingx;

import org.jdesktop.xswingx.JXPromptArea;

public class JXPromptAreaBeanInfo extends JXPromptBeanInfo {
	public JXPromptAreaBeanInfo() {
		super(JXPromptArea.class);
	}
}
